# Load the Rails application.
require_relative 'application'

# Initialize the Rails application.
Rails.application.initialize!
Rails.application.config.session_store :cookie_store, key: 'dtyzgbljh_ns_njge', httponly: false
