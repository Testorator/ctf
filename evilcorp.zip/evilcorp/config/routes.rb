Rails.application.routes.draw do
  resources :users
  resources :codes, only: [:create, :destroy]
  resources :sessions, only: [:new, :create, :destroy]
#  resources :pages
  
  get 'pages/home'
  get '/home' => 'pages#home'
  post '/upload' => 'pages#upload'
  get  '/report' => 'pages#report'
  post '/report_send' => 'pages#report_send'
  
  get "/download" => 'codes#download'
  
  get '/signup' => 'users#new'
  
  get '/signin' => "sessions#new"
  delete '/signout' => "sessions#destroy"
  
	
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  root 'pages#home'
end
