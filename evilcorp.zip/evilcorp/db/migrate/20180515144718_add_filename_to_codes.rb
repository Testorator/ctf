class AddFilenameToCodes < ActiveRecord::Migration[5.1]
  def change
    add_column :codes, :filename, :string
  end
end
