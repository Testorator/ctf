require 'rails_helper'

RSpec.describe CodesController, type: :controller do

end
