require 'zbar'
class CodesController < ApplicationController
	before_action :signed_in_user, only: [:create, :destroy]
	before_action :correct_user_code,   only: :destroy
	
	def index
	end

	def create
		param = code_params
		flag = ""
		if (param[:path].content_type == "image/jpeg")
		# need fix		
			uploaded_io = param[:path]
			file_internal = uploaded_io.read
			image = ZBar::Image.from_jpeg(file_internal)
			image.process.each do |result|
				logger.debug "Code: #{result.data} - Type: #{result.symbology}"
				flag = (result.data).gsub(/<[^>]*>/, "").encode('UTF-8', invalid: :replace, undef: :replace, replace: '?')
				logger.debug flag
			end
			
			if flag.length == 0
				flash[:danger]= "Why did you come here stinking cattle?"
				redirect_to root_url
			else
				param[:path] = flag
				filename = SecureRandom.uuid
				File.open(Rails.root.join('public', 'uploads', filename+".jpg"), 'wb') do |file|
					file.write(file_internal)
				end
				logger.debug param
				@code = current_user.codes.build(param)
				
				if @code.save
				   flash[:success] = "Code add!"
				    if @code.update_attribute(:filename, "/uploads/#{filename}.jpg")
				   		redirect_to root_url
				    else
				        flash[:danger] = "An has occurred error!"
				        render 'pages/home'
				    end   
				else
						@feed_items = []
						flash[:danger] = "An error has occurred!"
						render 'pages/home'
					end
			end	   		
		else
			@feed_items = []
			flash[:danger]="Poshel v zhopu, mamke svoey takoe otpravlyai!"
			redirect_to root_url   
		end
		
		
	end
	
    def destroy
    	File.delete("#{Rails.root}/public/#{@code.filename}")
        @code.destroy
        flash[:success] = "Code del!"
        redirect_to root_url
    end
    
    def download
      send_file("#{Rails.root}#{params[:file]}")
      
    end
    
end

private
	def code_params
	      params.require(:code).permit(:path, :file)
	end
	
	def correct_user_code
	      @code = current_user.codes.find_by(id: params[:id])
	      redirect_to root_url if @code.nil?      
	end
