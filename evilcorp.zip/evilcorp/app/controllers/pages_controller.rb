require "socket"
class PagesController < ApplicationController
  before_action :assign_default_params, only: :report_send
    
  def home
  	if signed_in?
	  	@code = current_user.codes.build
	  	@feed_items = current_user.feed
	end
  end
  
  def report
  end
  
  def report_send
  	logger.debug params[:url]
  	sock = TCPSocket.new '127.0.0.1', 12350
  	sock.write params[:url]
  	sock.close
  	redirect_to report_path
  	flash[:success]="Your request is accepted"
  end
  
end


private 
def page_params
      params.permit(:url)
end

def assign_default_params
#	logger.debug /\Ahtt(p|ps):\/\/[\w+\-.]+[a-z\d\-.]+\.[a-z].*\z/i.match(params[:url]).nil?
	if (/\Ahtt(p|ps):\/\/.*\z/i.match(params[:url]).nil?)
		redirect_to report_path
		flash[:danger]= "Che for bulshit? Scha banned!" 
	end
end