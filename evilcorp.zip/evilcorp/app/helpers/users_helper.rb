module UsersHelper
	
	# аватарка по дефолту в профиле
	def image_for(user,options = {size:52})
		image_tag("/unnamed.png", alt: user.name, size: options[:size], class: "img-circle")
	end
end