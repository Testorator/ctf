module SessionsHelper
  # авторизация и присваивание ремембер токена, также обновление его в бд
  def sign_in(user)
  	  if(user.remember_token==nil)
  	  	remember_token = User.new_remember_token
  	  	user.update_attribute(:remember_token, User.encrypt(remember_token))
  	  	cookies.permanent[:remember_token] = remember_token
  	  else
  	  	cookies.permanent[:remember_token] = user.remember_token
  	  end
      self.current_user = user
  end
  
  # локальная переменная @current_user
  def current_user=(user)
      @current_user = user
  end
  
  # ищем текущего пользователя по токену в бд
  def current_user
#      remember_token = User.encrypt(cookies[:remember_token])
	  remember_token = cookies[:remember_token]
      @current_user ||= User.find_by(remember_token: remember_token)
  end
  
  def current_user?(user)
      user == current_user
  end
  
  def it_adm?(user)
  	  current_user.admin?
  end
  
  def signed_in_user
  	unless signed_in?
	    store_location
	    redirect_to signin_url, notice: "Please sign in."
  	end
  end
  
  # авторизован ли?
  def signed_in?
      !current_user.nil?
  end
  
  # выход 
  def sign_out
#      current_user.update_attribute(:remember_token,User.encrypt(User.new_remember_token))
      cookies.delete(:remember_token)
      self.current_user = nil
  end
  
  def redirect_back_or(default)
      redirect_to(session[:return_to] || default)
      session.delete(:return_to)
  end
  
  def store_location
     session[:return_to] = request.url if request.get?
  end
  
end
