class User < ApplicationRecord
	has_many :codes, dependent: :destroy
	# валидация mail
	VALID_EMAIL_REGEX = /\A[\w+\-.]+@[a-z\d\-.]+\.[a-z]+\z/i
	validates :email, presence: true, format:  {with: VALID_EMAIL_REGEX }, uniqueness: { case_sensitive: false }
	# валидация имени
	validates :name, presence: true, length: { maximum: 50 }
	
	# валидация пароля
	has_secure_password
	validates :password, length: { minimum: 8 }
	
	before_save { self.email = email.downcase }
	# перед созданием, создаем токен
	before_create :create_remember_token
	
	# создание нового токена
	def User.new_remember_token
	    SecureRandom.urlsafe_base64
	end
	
	def feed
	    # Это предварительное решение. См. полную реализацию в "Following users".
	    Code.where("user_id = ?", id)
	end
	
	# шифрование токена
	def User.encrypt(token)
	    Digest::SHA2.hexdigest(token.to_s)
	end
	
	private
		# создание токена и его инициализация (remember_token = User.encrypt(User.new_remember_token))
		def create_remember_token
		      self.remember_token = User.encrypt(User.new_remember_token)
		end
end
